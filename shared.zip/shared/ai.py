import onnxruntime as ort
import cv2
import numpy as np
import time
import gpu_capture

screenshot = 640
center = screenshot / 2
countfps = True
visual = False                          
modelname = 'yolov8n.onnx'
aimpoint = 3.5

class Predict:
    def __init__(self, onnx_model, confidence_thres, iou_thres):
        self.confidence_thres = confidence_thres
        self.iou_thres = iou_thres
        
        options = ort.SessionOptions()
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_EXTENDED
        
        # Attivazione ufficiale DirectML in Python
        self.session = ort.InferenceSession(
            onnx_model, 
            sess_options=options,
            providers=['DmlExecutionProvider', 'CPUExecutionProvider']
        )

        self.get_input_details()
        self.get_output_details()
        self.classes = self.get_class_names()
        self.color_palette = np.random.uniform(0, 255, size=(len(self.classes), 3)).astype(np.uint8)

        # Inizializza la cattura hardware C++ Direct3D 11 stabile
        print("[SYSTEM] Inizializzazione modulo hardware C++...")
        if not gpu_capture.initialize_capture():
            raise RuntimeError("[ERRORE] Inizializzazione DirectX fallita.")

        self.binding = self.session.io_binding()
        for name in self.output_names:
            self.binding.bind_output(name, device_type='cpu')

    def detect_objects_zero_copy(self):
        # Il C++ esegue la cattura, lo shader RGB e ci restituisce l'array NumPy float32 pre-normalizzato
        input_tensor = gpu_capture.get_frame_image(True)
        
        if input_tensor is None:
            return "NO_NEW_FRAME"
            
        self.binding.clear_binding_inputs()
        
        # Binding standard: passiamo l'array NumPy float continuo. 
        # ONNX Runtime DirectML invia i float in VRAM in modo asincrono super ottimizzato.
        self.binding.bind_input(
            name=self.input_names[0],
            device_type='cpu', 
            device_id=0,
            element_type=np.float32,
            shape=[1, 3, self.input_height, self.input_width],
            buffer_ptr=input_tensor.ctypes.data # Indirizzo di memoria continuo sicuro
        )
        
        self.session.run_with_iobinding(self.binding)
        ort_outputs = self.binding.get_outputs()
        outputs = [out.numpy() for out in ort_outputs]
        return self.postprocess(outputs)

    def postprocess(self, outputs):
        outputs = np.squeeze(outputs[0]).T
        scores = np.max(outputs[:, 4:], axis=1)
        
        mask = scores > self.confidence_thres
        outputs = outputs[mask, :]
        scores = scores[mask]
        
        if len(scores) == 0:
            return []

        class_ids = np.argmax(outputs[:, 4:], axis=1)
        boxes = self.extract_boxes(outputs)
        indices = self.non_max_suppression(boxes, scores, self.iou_thres)
        
        arry_box = []
        for i in indices:
            box, score, class_id = boxes[i, :4], scores[i], class_ids[i]
            arry_box.append((box, score, class_id, self.classes[class_id]))
        return arry_box

    def xywh2xyxy(self, x):
        y = x.copy()
        y[..., 0] = x[..., 0] - x[..., 2] / 2
        y[..., 1] = x[..., 1] - x[..., 3] / 2
        y[..., 2] = x[..., 0] + x[..., 2] / 2
        y[..., 3] = x[..., 1] + x[..., 3] / 2
        return y

    def extract_boxes(self, predictions):
        boxes = predictions[:, :4]
        boxes = self.xywh2xyxy(boxes)
        return boxes

    def non_max_suppression(self, boxes, scores, iou_threshold):
        x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
        areas = (x2 - x1) * (y2 - y1)
        order = scores.argsort()[::-1]
        keep = []

        while order.size > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0, xx2 - xx1)
            h = np.maximum(0, yy2 - yy1)
            inter = w * h
            union = areas[i] + areas[order[1:]] - inter
            iou = inter / union
            order = order[1:][iou <= iou_threshold]

        return np.array(keep, dtype=np.int32)

    def get_input_details(self):
        model_inputs = self.session.get_inputs()
        self.input_names = [model_inputs[i].name for i in range(len(model_inputs))]
        self.input_shape = model_inputs[0].shape
        self.input_height = self.input_shape[2]
        self.input_width = self.input_shape[3]

    def get_output_details(self):
        model_outputs = self.session.get_outputs()
        self.output_names = [model_outputs[i].name for i in range(len(model_outputs))]

    def get_class_names(self):
        try:
            metadata = self.session.get_modelmeta().custom_metadata_map['names']
            return [item.split(": ")[1].strip(" {}'") for item in metadata.split("', ")]
        except:
            return [f"class_{i}" for i in range(80)]

    def draw_detections(self, img, box, score, class_id):
        x1, y1, x2, y2 = map(int, box)
        color = self.color_palette[class_id].tolist()
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
        label = f"Target: {score:.2f}"
        cv2.putText(img, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)


class ONNX:
    def __init__(self, onnx_model, confidence_thres, iou_thres):
        self.predict_model = Predict(onnx_model, confidence_thres, iou_thres)

    def __call__(self):
        return self.predict_model.detect_objects_zero_copy()


model = ONNX(modelname, 0.49, 0.5)
print("[SYSTEM] Pipeline DirectML avviata correttamente con successo.")
frame_count = 0
start_time = time.time()

while True:
    results = model()

    if results == "NO_NEW_FRAME":
        time.sleep(0.001)
        continue

    if results is not None:
        targets = []
        for box, score, class_id, cls in results:
            target_x = (box[0] + box[2]) / 2 - center
            target_y = box[1] + (box[3] - box[1]) / aimpoint - center
            targets.append((target_x, target_y))
        targets_array = np.array(targets)

        if len(targets_array) > 0:
            dist_from_center = np.linalg.norm(targets_array, axis=1)
            min_dist_idx = np.argmin(dist_from_center)
            current_target = targets_array[min_dist_idx]
            delta_x = int(current_target[0] / 2.4)
            delta_y = int(current_target[1] / 2.4)

        if visual:
            img = np.zeros((640, 640, 3), dtype=np.uint8)
            for box, score, class_id, cls in results:
                model.predict_model.draw_detections(img, box, score, class_id)
            cv2.imshow("Detected Objects", img)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        if countfps:
            frame_count += 1
            elapsed_time = time.time() - start_time
            if elapsed_time > 1:
                print(f"FPS Reali DirectML: {frame_count / elapsed_time:.2f}")
                frame_count = 0
                start_time = time.time()
