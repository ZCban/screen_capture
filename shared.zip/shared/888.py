import onnxruntime as ort
import cv2
import numpy as np
import time
import sys
import gpu_capture  # Il tuo modulo C++ D3D11 stabile
from PyQt5 import QtWidgets, QtGui, QtCore
from win32api import GetSystemMetrics

# --- CONFIGURAZIONI GEOMETRICHE HARDWARE ---
screenshot = 640
center = screenshot / 2
countfps = True
visual = True   # Attiviamo l'overlay PyQt5 su schermo
modelname = 'yolov8n.onnx'
aimpoint = 3.5

TARGET_FPS = 120
FRAME_TIME = 1 / TARGET_FPS

# Risoluzione reale del monitor per centrare la finestra trasparente
screen_width = GetSystemMetrics(0)
screen_height = GetSystemMetrics(1)
x_pos = (screen_width - screenshot) // 2
y_pos = (screen_height - screenshot) // 2


class Predict:
    def __init__(self, onnx_model, confidence_thres, iou_thres):
        self.confidence_thres = confidence_thres
        self.iou_thres = iou_thres
        
        options = ort.SessionOptions()
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_EXTENDED
        
        self.session = ort.InferenceSession(
            onnx_model, 
            sess_options=options,
            providers=['DmlExecutionProvider', 'CPUExecutionProvider']
        )

        self.get_input_details()
        self.get_output_details()
        self.classes = self.get_class_names()

        # Inizializza la cattura hardware C++ Direct3D 11 stabile
        print("[SYSTEM] Inizializzazione modulo hardware C++...")
        if not gpu_capture.initialize_capture():
            raise RuntimeError("[ERRORE] Inizializzazione DirectX fallita.")

        self.binding = self.session.io_binding()
        for name in self.output_names:
            self.binding.bind_output(name, device_type='cpu')

    def detect_objects_zero_copy(self):
        # Il C++ esegue la cattura, lo shader RGB e ci restituisce l'array NumPy float32 pre-normalizzato
        input_tensor = gpu_capture.get_frame_image(True)
        
        if input_tensor is None:
            return "NO_NEW_FRAME"
            
        self.binding.clear_binding_inputs()
        
        # Inserito l'indice fisso del nome dell'input per compatibilità totale
        self.binding.bind_input(
            name=self.input_names[0],
            device_type='cpu', 
            device_id=0,
            element_type=np.float32,
            shape=[1, 3, self.input_height, self.input_width],
            buffer_ptr=input_tensor.ctypes.data
        )
        
        self.session.run_with_iobinding(self.binding)
        ort_outputs = self.binding.get_outputs()
        outputs = [out.numpy() for out in ort_outputs]
        return self.postprocess(outputs)

    def postprocess(self, outputs):
        outputs = np.squeeze(outputs[0]).T
        scores = np.max(outputs[:, 4:], axis=1)
        
        mask = scores > self.confidence_thres
        outputs = outputs[mask, :]
        scores = scores[mask]
        
        if len(scores) == 0:
            return []

        class_ids = np.argmax(outputs[:, 4:], axis=1)
        boxes = self.extract_boxes(outputs)
        indices = self.non_max_suppression(boxes, scores, self.iou_thres)
        
        arry_box = []
        for i in indices:
            box, score, class_id = boxes[i, :4], scores[i], class_ids[i]
            arry_box.append((box, score, class_id, self.classes[class_id]))
        return arry_box

    def xywh2xyxy(self, x):
        y = x.copy()
        y[..., 0] = x[..., 0] - x[..., 2] / 2
        y[..., 1] = x[..., 1] - x[..., 3] / 2
        y[..., 2] = x[..., 0] + x[..., 2] / 2
        y[..., 3] = x[..., 1] + x[..., 3] / 2
        return y

    def extract_boxes(self, predictions):
        boxes = predictions[:, :4]
        boxes = self.xywh2xyxy(boxes)
        return boxes

    def non_max_suppression(self, boxes, scores, iou_threshold):
        x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
        areas = (x2 - x1) * (y2 - y1)
        order = scores.argsort()[::-1]
        keep = []

        while order.size > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0, xx2 - xx1)
            h = np.maximum(0, yy2 - yy1)
            inter = w * h
            union = areas[i] + areas[order[1:]] - inter
            iou = inter / union
            order = order[1:][iou <= iou_threshold]

        return np.array(keep, dtype=np.int32)

    def get_input_details(self):
        model_inputs = self.session.get_inputs()
        self.input_names = [model_inputs[i].name for i in range(len(model_inputs))]
        self.input_shape = model_inputs[0].shape
        self.input_height = self.input_shape[2]
        self.input_width = self.input_shape[3]

    def get_output_details(self):
        model_outputs = self.session.get_outputs()
        self.output_names = [model_outputs[i].name for i in range(len(model_outputs))]

    def get_class_names(self):
        try:
            metadata = self.session.get_modelmeta().custom_metadata_map['names']
            return [item.split(": ")[1].strip(" {}'") for item in metadata.split("', ")]
        except:
            return [f"class_{i}" for i in range(80)]


class ONNX:
    def __init__(self, onnx_model, confidence_thres, iou_thres):
        self.predict_model = Predict(onnx_model, confidence_thres, iou_thres)

    def __call__(self):
        return self.predict_model.detect_objects_zero_copy()


# --- THREAD ASINCRONO DI CALCOLO HARDWARE ---
class AIExecutionThread(QtCore.QThread):
    # Segnale per inviare le sole coordinate delle box all'interfaccia grafica
    update_overlay_signal = QtCore.pyqtSignal(list)

    def __init__(self, model_instance, parent=None):
        super().__init__(parent)
        self.model = model_instance
        self.running = True
        self.frame_count = 0
        self.start_time = time.time()

    def run(self):
        print("[SYSTEM] Loop hardware DirectML avviato alla massima velocità.")
        while self.running:
            #loop_start = time.time()
            results = self.model()

            if results == "NO_NEW_FRAME":
                time.sleep(0.001)
                continue

            if results is not None:
                targets = []
                new_bboxes = []
                
                for box, score, class_id, cls in results:
                    # Calcolo matematico dei delta per il puntatore mouse_event / Arduino
                    target_x = (box[0] + box[2]) / 2 - center
                    target_y = box[1] + (box[3] - box[1]) / aimpoint - center
                    targets.append((target_x, target_y))
                    
                    # Pacchetto coordinate per l'overlay grafico trasparente
                    new_bboxes.append((box[0], box[1], box[2], box[3], cls, score))
                    
                targets_array = np.array(targets)
                if len(targets_array) > 0:
                    dist_from_center = np.linalg.norm(targets_array, axis=1)
                    min_dist_idx = np.argmin(dist_from_center)
                    current_target = targets_array[min_dist_idx]
                    
                    delta_x = int(current_target[0] / 2.4)
                    delta_y = int(current_target[1] / 2.4)
                    # SBLOCCO ARDUINO / MOUSE: Inserisci qui l'invio fisico dei movimenti
                    # print(f"Spostamento -> X: {delta_x}, Y: {delta_y}")

                # Inviamo i rettangoli alla finestra PyQt5 in modo asincrono
                if visual:
                    self.update_overlay_signal.emit(new_bboxes)

            # Monitoraggio FPS reali sulla console
            if countfps:
                self.frame_count += 1
                elapsed_time = time.time() - self.start_time
                if elapsed_time > 1:
                    print(f"FPS Reali DirectML Pipeline: {self.frame_count / elapsed_time:.2f}")
                    self.frame_count = 0
                    self.start_time = time.time()

            # Sincronizzazione frame rate per non sprecare risorse utili
            #loop_elapsed = time.time() - loop_start
            #if loop_elapsed < FRAME_TIME:
            #    time.sleep(FRAME_TIME - loop_elapsed)


# --- FINESTRA OVERLAY TRASPARENTE (NATIVA WINDOWS) ---
class TransparentOverlay(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.current_boxes = []
        self.init_window_properties()

    def init_window_properties(self):
        # Rende la finestra invisibile al mouse, senza bordi e perennemente in primo piano (StaysOnTop)
        self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowTransparentForInput)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setGeometry(x_pos, y_pos, screenshot, screenshot)
        self.show()

    def draw_updated_boxes(self, bboxes):
        self.current_boxes = bboxes
        self.update() # Richiama automaticamente la funzione hardware paintEvent

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        # Disegna le bounding box dell'IA (Rosso vivido e pulito)
        for (x1, y1, x2, y2, cls_name, conf_score) in self.current_boxes:
            w = int(x2 - x1)
            h = int(y2 - y1)
            
            # Rettangolo di tracciamento nemico
            painter.setPen(QtGui.QPen(QtGui.QColor(255, 0, 0, 230), 2, QtCore.Qt.SolidLine))
            painter.drawRect(int(x1), int(y1), w, h)
            
            # Scritta di debug (Classe + Confidenza) stampata sopra la box
            painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255, 255)))
            painter.setFont(QtGui.QFont("Arial", 9, QtGui.QFont.Bold))
            painter.drawText(int(x1), int(y1) - 5, f"{cls_name} {conf_score:.2f}")


if __name__ == "__main__":
    # Inizializziamo l'istanza grafica di Windows
    app = QtWidgets.QApplication(sys.argv)
    
    # Caricamento del modello DirectML
    model = ONNX(modelname, 0.49, 0.5)
    print("[SYSTEM] Pipeline DirectML avviata correttamente con successo.")
    
    # Avvio overlay trasparente nativo
    overlay_window = TransparentOverlay()
    
    # Spostiamo il loop di inferenza su un thread separato per garantire 120 FPS fluidi
    ai_thread = AIExecutionThread(model)
    ai_thread.update_overlay_signal.connect(overlay_window.draw_updated_boxes)
    ai_thread.start()
    
    sys.exit(app.exec_())
