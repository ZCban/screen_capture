#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <dxgi1_3.h>
#include <d2d1_1.h>
#include <d2d1effects.h>
#include <d3dcompiler.h> 
#include <iostream>
#include <string>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

namespace py = pybind11;

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "d3dcompiler.lib") 

// --- RISORSE GRAFICHE GLOBALI DINAMICHE ---
ID3D11Device* pDevice = nullptr;
ID3D11DeviceContext* pDeviceContext = nullptr;
ID2D1DeviceContext* pD2DContext = nullptr;
IDXGIOutputDuplication* pDeskDupl = nullptr;
ID2D1Effect* pColorMatrixEffect = nullptr;
ID3D11Texture2D* pGpuTargetTexture = nullptr;
ID2D1Bitmap1* pD2DTargetBitmap = nullptr;
ID2D1Bitmap1* pLastValidBitmap = nullptr;

ID3D11ComputeShader* pComputeShader = nullptr;
ID3D11Buffer* pParamBuffer = nullptr;
ID3D11Buffer* pGpuFloatOutputBuffer = nullptr;
ID3D11Buffer* pStagingBuffer = nullptr;
ID3D11ShaderResourceView* pInputSRV = nullptr;
ID3D11UnorderedAccessView* pOutputUAV = nullptr;

UINT cropLeft = 0, cropTop = 0;
UINT cropWidth = 640;
UINT cropHeight = 640;

// Codice dello shader con parametri modificati a runtime
const char* computeShaderSrc = R"hlsl(
Texture2D<float4> InputTexture : register(t0);
RWStructuredBuffer<float> OutputBuffer : register(u0);
cbuffer Params : register(b0) { uint Width; uint Height; };
[numthreads(16, 16, 1)]
void CSMain(uint3 id : SV_DispatchThreadID) {
    if (id.x >= Width || id.y >= Height) return;
    float4 pixel = InputTexture.mips[0][id.xy];
    uint planeSize = Width * Height;
    uint pixelIdx = id.y * Width + id.x;
    OutputBuffer[pixelIdx] = pixel.r; 
    OutputBuffer[planeSize + pixelIdx] = pixel.g; 
    OutputBuffer[2 * planeSize + pixelIdx] = pixel.b; 
}
)hlsl";

bool initialize_capture(UINT width, UINT height) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    // Configurazione dinamica dei parametri estratti da Python
    cropWidth = width;
    cropHeight = height;

    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    cropLeft = (screenWidth - cropWidth) / 2;
    cropTop = (screenHeight - cropHeight) / 2;

    D3D_FEATURE_LEVEL featureLevel;
    D3D_FEATURE_LEVEL featureLevels[] = { D3D_FEATURE_LEVEL_11_0 };
    if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, featureLevels, 1, D3D11_SDK_VERSION, &pDevice, &featureLevel, &pDeviceContext))) return false;

    IDXGIDevice* pDxgiDevice = nullptr; pDevice->QueryInterface(__uuidof(IDXGIDevice), (void**)&pDxgiDevice);
    IDXGIAdapter* pDxgiAdapter = nullptr; pDxgiDevice->GetParent(__uuidof(IDXGIAdapter), (void**)&pDxgiAdapter);
    ID2D1Factory1* pD2DFactory = nullptr; D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, __uuidof(ID2D1Factory1), nullptr, (void**)&pD2DFactory);
    ID2D1Device* pD2DDevice = nullptr; pD2DFactory->CreateDevice(pDxgiDevice, &pD2DDevice);
    pD2DDevice->CreateDeviceContext(D2D1_DEVICE_CONTEXT_OPTIONS_NONE, &pD2DContext);

    D3D11_TEXTURE2D_DESC desc = {};
    desc.Width = cropWidth; desc.Height = cropHeight; desc.MipLevels = 1; desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM; desc.SampleDesc.Count = 1; desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    if (FAILED(pDevice->CreateTexture2D(&desc, nullptr, &pGpuTargetTexture))) return false;

    IDXGISurface* pTargetSurface = nullptr; pGpuTargetTexture->QueryInterface(__uuidof(IDXGISurface), (void**)&pTargetSurface);
    pD2DContext->CreateBitmapFromDxgiSurface(pTargetSurface, nullptr, &pD2DTargetBitmap); pTargetSurface->Release();

    D2D1_BITMAP_PROPERTIES1 bitmapProps = D2D1::BitmapProperties1(D2D1_BITMAP_OPTIONS_TARGET, D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE));
    pD2DContext->CreateBitmap(D2D1::SizeU(cropWidth, cropHeight), nullptr, 0, &bitmapProps, &pLastValidBitmap);

    IDXGIOutput* pDxgiOutput = nullptr; pDxgiAdapter->EnumOutputs(0, &pDxgiOutput); pDxgiAdapter->Release();
    IDXGIOutput1* pDxgiOutput1 = nullptr; pDxgiOutput->QueryInterface(__uuidof(IDXGIOutput1), (void**)&pDxgiOutput1); pDxgiOutput1->Release();
    HRESULT hr = pDeskDupl ? S_OK : pDxgiOutput1->DuplicateOutput(pDevice, &pDeskDupl);
    pDxgiOutput1->Release(); pDxgiDevice->Release(); pD2DDevice->Release(); pD2DFactory->Release();
    if (FAILED(hr)) return false;

    pD2DContext->CreateEffect(CLSID_D2D1ColorMatrix, &pColorMatrixEffect);
    D2D1_MATRIX_5X4_F bgraToRgbaMatrix = D2D1::Matrix5x4F(0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f);
    pColorMatrixEffect->SetValue(D2D1_COLORMATRIX_PROP_COLOR_MATRIX, bgraToRgbaMatrix);

    ID3DBlob* shaderBlob = nullptr; ID3DBlob* errorBlob = nullptr;
    hr = D3DCompile(computeShaderSrc, strlen(computeShaderSrc), nullptr, nullptr, nullptr, "CSMain", "cs_5_0", 0, 0, &shaderBlob, &errorBlob);
    if (FAILED(hr)) { if (errorBlob) errorBlob->Release(); return false; }
    pDevice->CreateComputeShader(shaderBlob->GetBufferPointer(), shaderBlob->GetBufferSize(), nullptr, &pComputeShader); shaderBlob->Release();

    pDevice->CreateShaderResourceView(pGpuTargetTexture, nullptr, &pInputSRV);

    // ALLOCAZIONE DINAMICA DEI BUFFER HARDWARE BASATA SULLA MATRICE DI INPUT
    D3D11_BUFFER_DESC bufferDesc = {};
    bufferDesc.BindFlags = D3D11_BIND_UNORDERED_ACCESS;
    bufferDesc.ByteWidth = cropWidth * cropHeight * 3 * sizeof(float);
    bufferDesc.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;
    bufferDesc.StructureByteStride = sizeof(float);
    bufferDesc.Usage = D3D11_USAGE_DEFAULT;
    if (FAILED(pDevice->CreateBuffer(&bufferDesc, nullptr, &pGpuFloatOutputBuffer))) return false;

    D3D11_UNORDERED_ACCESS_VIEW_DESC uavDesc = {};
    uavDesc.Format = DXGI_FORMAT_UNKNOWN; uavDesc.ViewDimension = D3D11_UAV_DIMENSION_BUFFER; uavDesc.Buffer.NumElements = cropWidth * cropHeight * 3;
    if (FAILED(pDevice->CreateUnorderedAccessView(pGpuFloatOutputBuffer, &uavDesc, &pOutputUAV))) return false;

    D3D11_BUFFER_DESC cbDesc = {}; cbDesc.ByteWidth = 16; cbDesc.Usage = D3D11_USAGE_IMMUTABLE; cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    UINT dims[] = { cropWidth, cropHeight, 0, 0 };
    D3D11_SUBRESOURCE_DATA cbData = {}; cbData.pSysMem = dims;
    if (FAILED(pDevice->CreateBuffer(&cbDesc, &cbData, &pParamBuffer))) return false;

    D3D11_BUFFER_DESC stDesc = {};
    stDesc.ByteWidth = cropWidth * cropHeight * 3 * sizeof(float);
    stDesc.Usage = D3D11_USAGE_STAGING;
    stDesc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    if (FAILED(pDevice->CreateBuffer(&stDesc, nullptr, &pStagingBuffer))) return false;

    return true;
}

py::object get_frame_image(bool utilizza_rgba) {
    IDXGIResource* pDesktopResource = nullptr; DXGI_OUTDUPL_FRAME_INFO frameInfo; ID3D11Texture2D* pAcquiredTexture = nullptr; bool nuovoFrameRilevato = false;
    while (pDeskDupl->AcquireNextFrame(0, &frameInfo, &pDesktopResource) == S_OK) {
        if (nuovoFrameRilevato && pAcquiredTexture) { pAcquiredTexture->Release(); pDeskDupl->ReleaseFrame(); }
        if (pDesktopResource) { pDesktopResource->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&pAcquiredTexture); pDesktopResource->Release(); nuovoFrameRilevato = true; }
    }
    if (!nuovoFrameRilevato) return py::none();

    IDXGISurface* pScanSurface = nullptr; pAcquiredTexture->QueryInterface(__uuidof(IDXGISurface), (void**)&pScanSurface);
    ID2D1Bitmap1* pD2DInputBitmap = nullptr; pD2DContext->CreateBitmapFromDxgiSurface(pScanSurface, nullptr, &pD2DInputBitmap);

    if (pD2DInputBitmap) {
        pD2DContext->SetTarget(pLastValidBitmap); pD2DContext->BeginDraw();
        D2D1_RECT_F srcRect = D2D1::RectF((float)cropLeft, (float)cropTop, (float)(cropLeft + cropWidth), (float)(cropTop + cropHeight));
        D2D1_POINT_2F destOffset = D2D1::Point2F(0.0f, 0.0f);
        if (utilizza_rgba) {
            pColorMatrixEffect->SetInput(0, pD2DInputBitmap); ID2D1Image* pEffectOutput = nullptr; pColorMatrixEffect->GetOutput(&pEffectOutput);
            pD2DContext->DrawImage(pEffectOutput, &destOffset, &srcRect, D2D1_INTERPOLATION_MODE_LINEAR, D2D1_COMPOSITE_MODE_SOURCE_COPY); pEffectOutput->Release();
        }
        else {
            pD2DContext->DrawImage(pD2DInputBitmap, &destOffset, &srcRect, D2D1_INTERPOLATION_MODE_LINEAR, D2D1_COMPOSITE_MODE_SOURCE_COPY);
        }
        pD2DContext->EndDraw();
        pD2DContext->SetTarget(pD2DTargetBitmap); pD2DContext->BeginDraw();
        pD2DContext->DrawImage(pLastValidBitmap, &destOffset, nullptr, D2D1_INTERPOLATION_MODE_LINEAR, D2D1_COMPOSITE_MODE_SOURCE_COPY);
        pD2DContext->EndDraw();
        pD2DInputBitmap->Release();
    }
    pScanSurface->Release(); pAcquiredTexture->Release();

    pDeviceContext->Flush();
    pDeviceContext->CSSetShader(pComputeShader, nullptr, 0);
    pDeviceContext->CSSetShaderResources(0, 1, &pInputSRV);
    pDeviceContext->CSSetUnorderedAccessViews(0, 1, &pOutputUAV, nullptr);
    pDeviceContext->CSSetConstantBuffers(0, 1, &pParamBuffer);

    // Esecuzione dinamica basata sui blocchi hardware da 16 thread distribuiti
    pDeviceContext->Dispatch((cropWidth + 15) / 16, (cropHeight + 15) / 16, 1);

    ID3D11UnorderedAccessView* nullUAV[] = { nullptr }; ID3D11ShaderResourceView* nullSRV[] = { nullptr }; ID3D11Buffer* nullCB[] = { nullptr };
    pDeviceContext->CSSetUnorderedAccessViews(0, 1, nullUAV, nullptr); pDeviceContext->CSSetShaderResources(0, 1, nullSRV); pDeviceContext->CSSetConstantBuffers(0, 1, nullCB);
    pDeskDupl->ReleaseFrame();

    pDeviceContext->CopyResource(pStagingBuffer, pGpuFloatOutputBuffer);

    py::array_t<float> result_array({ 1, 3, (int)cropHeight, (int)cropWidth });
    D3D11_MAPPED_SUBRESOURCE mappedRes;
    if (SUCCEEDED(pDeviceContext->Map(pStagingBuffer, 0, D3D11_MAP_READ, 0, &mappedRes))) {
        std::memcpy(result_array.mutable_data(), mappedRes.pData, cropWidth * cropHeight * 3 * sizeof(float));
        pDeviceContext->Unmap(pStagingBuffer, 0);
    }

    return result_array;
}

PYBIND11_MODULE(gpu_capture, m) {
    m.def("initialize_capture", &initialize_capture);
    m.def("get_frame_image", &get_frame_image);
}
